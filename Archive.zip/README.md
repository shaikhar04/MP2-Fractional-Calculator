Author: Arsal Shaikh

Purpose: Calculator app and BigFractions class. Evaluates indivisual expressions like a calculator. QuickCalculator works with commandline arguments. Supports saving answers in registers.